exports.getProtectedResource = (req, res) => {
    res.send('Authentication was successful');
};