import React, { useState } from "react";
import api from "../server";

const Dashboard = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [animais, setAnimais] = useState([]);
  const [animalDashboard, setAnimalDashboard] = useState(null);

  const handleSearch = async (e) => {
    e.preventDefault();
    try {
      const response = await api.get(`/animais?nome_like=${searchQuery}`);
      setAnimais(response.data);
    } catch (error) {
      console.error("Error searching animais:", error);
    }
  };

  const fetchAnimalDashboard = async (id) => {
    try {
      const response = await api.get(`/animal/${id}`);
      setAnimalDashboard(response.data);
    } catch (error) {
      console.error("Error fetching animal detail:", error);
    }
  };

  return (
    <div className="dashboard">
      <h2>Dashboard</h2>
      <form onSubmit={handleSearch}>
        <label>
          Search Animal:
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </label>
        <button type="submit">Search</button>
      </form>

      <div className="animal-list">
        <h3>Animals</h3>
        <ul>
          {animais.map((animal) => (
            <li key={animal.id} onClick={() => fetchAnimalDashboard(animal.id)}>
              {animal.nome}
            </li>
          ))}
        </ul>
      </div>

      {animalDashboard && (
        <div className="animal-dashboard">
          <h3>Animal:</h3>
          <p><strong>Nome:</strong> {animalDetalhe.id}</p>
          <p><strong>Tipo de Conta:</strong> {animalDetalhe.name}</p>
          <p><strong>Número Fiscal:</strong> {animalDetalhe.age}</p>
          <p><strong>Email:</strong> {animalDetalhe.typeAnimal}</p>
          <p><strong>Contacto:</strong> {animalDetalhe.breed}</p>
          <p><strong>Plano:</strong> {animalDetalhe.description}</p>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
